import SwiftUI
import UIKit
import UniformTypeIdentifiers
import CryptoKit

// MARK: - UTType policy (unchanged)
private enum PatchPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "3105") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
    static let copiesSelectedDocument = true
}

// MARK: - Online file model (unchanged)
struct OnlineFileItem: Codable, Identifiable {
    let id: String
    let title: String
    let filename: String
    let url: String
    let status: Bool
    let created_at: Int
    let sha256: String?
    let packageID: String?

    init(
        id: String,
        title: String,
        filename: String,
        url: String,
        status: Bool,
        created_at: Int,
        sha256: String? = nil,
        packageID: String? = nil
    ) {
        self.id = id
        self.title = title
        self.filename = filename
        self.url = url
        self.status = status
        self.created_at = created_at
        self.sha256 = sha256
        self.packageID = packageID
    }

    enum CodingKeys: String, CodingKey {
        case id, title, filename, url, status, created_at, sha256
        case packageID = "package_id"
    }
}

// MARK: - Online file fetcher (unchanged)
@MainActor
final class OnlineFileFetcher: ObservableObject {
    @Published var onlineFiles: [OnlineFileItem] = []
    @Published var isLoading: Bool = false
    private(set) var lastFetchSucceeded = false

    private var obfuscatedAPIURL: String {
        // Patch list API: GET https://appfluxcore.site/api/patches_list.php?app=3105
        let encryptedBytes: [UInt8] = [
            0x69, 0x75, 0x75, 0x71, 0x72, 0x3B, 0x2E, 0x2E, 0x60, 0x71, 0x71, 0x67, 0x6D, 0x74, 0x79, 0x62, 0x6E, 0x73, 0x64, 0x2F, 0x72, 0x68, 0x75, 0x64, 0x2E, 0x60, 0x71, 0x68, 0x2E, 0x71, 0x60, 0x75, 0x62, 0x69, 0x64, 0x72, 0x5E, 0x6D, 0x68, 0x72, 0x75, 0x2F, 0x71, 0x69, 0x71, 0x3E, 0x60, 0x71, 0x71, 0x3C, 0x32, 0x30, 0x31, 0x34
        ]
        let xorKey: UInt8 = 0x01
        let decryptedBytes = encryptedBytes.map { $0 ^ xorKey }
        return String(bytes: decryptedBytes, encoding: .utf8) ?? ""
    }

    func fetchServerFiles() async {
        guard let url = URL(string: obfuscatedAPIURL) else { return }
        isLoading = true
        lastFetchSucceeded = false
        defer { isLoading = false }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.timeoutInterval = 15
            let (data, _) = try await URLSession.shared.data(for: request)
            let decoded = try JSONDecoder().decode([OnlineFileItem].self, from: data)
            onlineFiles = decoded.filter { $0.status }
            lastFetchSucceeded = true
        } catch {
            log("online-files: fetch failed – \(error.localizedDescription)")
        }
    }

    /// Synchronizes every active server patch for the launch gate.
    ///
    /// A package already present in the local library is considered satisfied.
    /// Otherwise a validated per-server-id cache entry is reused before any
    /// network request is attempted. Downloads are atomic and, when the API
    /// supplies sha256, checksum verified before import.
    func preloadAllPatches(
        files: [OnlineFileItem],
        store: PatchProjectStore,
        progress: @escaping @MainActor (Int, Int, Int, String) -> Void,
        itemResult: @escaping @MainActor (OnlineFileItem, Bool) -> Void = { _, _ in }
    ) async -> Bool {
        guard !files.isEmpty else { return true }

        let localNames = await Task.detached(priority: .userInitiated) {
            let localItems = PatchProjectLibrary.load()
            return Set(localItems.map { item in
                var identities = [item.packageURL.deletingPathExtension().lastPathComponent]
                if let project = item.project {
                    identities.append(project.name)
                }
                return identities.map(Self.normalizedLocalIdentity)
            }.flatMap { $0 })
        }.value

        var completed = 0
        var failed = 0

        await reconcileMissingServerPackages(manifest: files)

        for file in files {
            if Task.isCancelled { return false }

            progress(completed, files.count, failed, file.title)

            let ok: Bool
            if isAlreadyInstalled(file: file, localNames: localNames) {
                log("startup-patch: local package found, skip download – \(file.title)")
                ok = true
            } else {
                ok = await synchronizePatch(file: file, store: store)
            }

            if ok {
                completed += 1
                markServerManaged(file)
            } else {
                failed += 1
            }

            itemResult(file, ok)
            progress(completed, files.count, failed, file.title)
        }

        // Launch readiness is an integrity gate: exposing the UI after only
        // some active server packages were imported would violate the startup
        // contract and leave patch state ambiguous.
        return !Task.isCancelled && failed == 0
    }

    private func reconcileMissingServerPackages(manifest: [OnlineFileItem]) async {
        let key = "PatchProjects.serverManagedPackageIDs.v1"
        let previous = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        let current = Set(manifest.compactMap { normalizedPackageID($0.packageID) })
        guard !previous.isEmpty else {
            persistManagedPackageIDs(current, key: key)
            return
        }

        let missing = previous.subtracting(current)
        guard !missing.isEmpty else {
            persistManagedPackageIDs(current, key: key)
            return
        }

        let localItems = PatchProjectLibrary.load()
        for item in localItems {
            let packageID = item.summary.packageID.uuidString.lowercased()
            guard missing.contains(packageID) else { continue }

            do {
                if let receipt = DevicePatchService.latestAppliedReceipt(projectID: item.id) {
                    try DevicePatchService.restore(receipt: receipt)
                }
                try PatchProjectLibrary.delete(item)
                log("patch-sync: server source disappeared; local package deleted and patch disabled – \(packageID)")
            } catch {
                log("patch-sync: failed to remove missing package \(packageID): \(error.localizedDescription)")
            }
        }

        persistManagedPackageIDs(current, key: key)
    }

    private func removeManagedPackage(for file: OnlineFileItem) {
        guard let packageID = normalizedPackageID(file.packageID) else { return }
        guard let item = PatchProjectLibrary.load().first(where: {
            $0.summary.packageID.uuidString.lowercased() == packageID
        }) else { return }

        do {
            if let receipt = DevicePatchService.latestAppliedReceipt(projectID: item.id) {
                try DevicePatchService.restore(receipt: receipt)
            }
            try PatchProjectLibrary.delete(item)
            log("patch-sync: source not found; local package deleted and patch disabled – \(packageID)")
        } catch {
            log("patch-sync: failed to disable missing package \(packageID): \(error.localizedDescription)")
        }
    }

    private func markServerManaged(_ file: OnlineFileItem) {
        guard let packageID = normalizedPackageID(file.packageID) else { return }
        let key = "PatchProjects.serverManagedPackageIDs.v1"
        var ids = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        ids.insert(packageID)
        persistManagedPackageIDs(ids, key: key)
    }

    private func persistManagedPackageIDs(_ ids: Set<String>, key: String) {
        UserDefaults.standard.set(Array(ids).sorted(), forKey: key)
    }

    private func normalizedPackageID(_ raw: String?) -> String? {
        guard let raw, let uuid = UUID(uuidString: raw) else { return nil }
        return uuid.uuidString.lowercased()
    }

    private func synchronizePatch(
        file: OnlineFileItem,
        store: PatchProjectStore
    ) async -> Bool {
        if let cached = cachedStartupPackageURL(for: file),
           validateCachedPackage(cached, expectedSHA256: file.sha256) {
            log("startup-patch: using local download cache – \(file.title)")
            return await importLocalPackage(cached, store: store, removeCacheAfterSuccess: true)
        }

        guard let rawURL = file.url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: rawURL),
              url.scheme?.lowercased() == "https" else {
            log("startup-patch: invalid HTTPS URL – \(file.title)")
            return false
        }

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 45
        config.timeoutIntervalForResource = 300
        config.waitsForConnectivity = true

        do {
            let (tmp, response) = try await URLSession(configuration: config).download(from: url)
            defer { try? FileManager.default.removeItem(at: tmp) }

            guard let http = response as? HTTPURLResponse else {
                return false
            }
            if http.statusCode == 404 || http.statusCode == 410 {
                removeManagedPackage(for: file)
                return false
            }
            guard (200..<300).contains(http.statusCode), isSafeRegularFile(tmp) else {
                return false
            }

            if let expected = normalizedSHA256(file.sha256) {
                guard try sha256(of: tmp) == expected else {
                    log("startup-patch: checksum mismatch – \(file.title)")
                    return false
                }
            }

            let cacheURL = startupCacheURL(for: file)
            try FileManager.default.createDirectory(
                at: startupCacheDirectory(),
                withIntermediateDirectories: true
            )
            try atomicReplace(source: tmp, destination: cacheURL)

            return await importLocalPackage(
                cacheURL,
                store: store,
                removeCacheAfterSuccess: true
            )
        } catch is CancellationError {
            return false
        } catch {
            log("startup-patch: \(file.title): \(error.localizedDescription)")
            return false
        }
    }

    private func importLocalPackage(
        _ packageURL: URL,
        store: PatchProjectStore,
        removeCacheAfterSuccess: Bool
    ) async -> Bool {
        guard isSafeRegularFile(packageURL) else { return false }

        store.importPackage(at: packageURL)
        let finished = await waitUntilImportFinishes(store: store, timeout: 45)
        // A password-protected package can finish the import operation by
        // presenting a password request while isBusy becomes false. It is not
        // actually installed yet, so retain the cache and report failure.
        let requiresPassword = store.passwordRequest != nil
        let ok = finished && !requiresPassword

        if ok && removeCacheAfterSuccess {
            try? FileManager.default.removeItem(at: packageURL)
        }
        return ok
    }

    private func isAlreadyInstalled(
        file: OnlineFileItem,
        localNames: Set<String>
    ) -> Bool {
        let filename = normalizedPackageFilename(file.filename, fallbackURL: file.url)
        if localNames.contains(Self.normalizedLocalIdentity(filename)) {
            return true
        }

        let titleIdentity = Self.normalizedLocalIdentity(file.title)
        return !titleIdentity.isEmpty && localNames.contains(titleIdentity)
    }

    private nonisolated static func normalizedLocalIdentity(_ raw: String) -> String {
        String(
            raw.unicodeScalars
                .filter { CharacterSet.alphanumerics.contains($0) }
                .map { Character($0) }
        ).lowercased()
    }

    private func normalizedPackageFilename(_ raw: String, fallbackURL: String) -> String {
        let candidate = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let base = candidate.isEmpty
            ? (URL(string: fallbackURL)?.lastPathComponent ?? "Patch")
            : candidate
        return base.lowercased().hasSuffix(".3105") ? base : "\(base).3105"
    }

    private func startupCacheDirectory() -> URL {
        FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        )[0].appendingPathComponent("StartupPatchCache.v1", isDirectory: true)
    }

    private func startupCacheURL(for file: OnlineFileItem) -> URL {
        let digest = SHA256.hash(data: Data(file.id.utf8))
            .map { String(format: "%02x", $0) }
            .joined()
        return startupCacheDirectory().appendingPathComponent("\(digest).3105")
    }

    private func cachedStartupPackageURL(for file: OnlineFileItem) -> URL? {
        let url = startupCacheURL(for: file)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    private func validateCachedPackage(_ url: URL, expectedSHA256: String?) -> Bool {
        guard isSafeRegularFile(url) else { return false }
        guard let expected = normalizedSHA256(expectedSHA256) else { return true }
        return (try? sha256(of: url)) == expected
    }

    private func normalizedSHA256(_ raw: String?) -> String? {
        guard let raw else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard value.count == 64,
              value.unicodeScalars.allSatisfy({ $0.properties.isASCIIHexDigit }) else {
            return nil
        }
        return value
    }

    private func sha256(of url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }

        var hasher = SHA256()
        while let chunk = try handle.read(upToCount: 4 * 1_024 * 1_024), !chunk.isEmpty {
            if Task.isCancelled { throw CancellationError() }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private func isSafeRegularFile(_ url: URL) -> Bool {
        guard let values = try? url.resourceValues(forKeys: [
            .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey
        ]) else { return false }
        return values.isRegularFile == true &&
               values.isSymbolicLink != true &&
               (values.fileSize ?? 0) > 0
    }

    private func atomicReplace(source: URL, destination: URL) throws {
        let fm = FileManager.default
        let staging = destination.deletingLastPathComponent()
            .appendingPathComponent(".staging-\(UUID().uuidString)")
        defer { try? fm.removeItem(at: staging) }

        try fm.copyItem(at: source, to: staging)
        if fm.fileExists(atPath: destination.path) {
            try fm.removeItem(at: destination)
        }
        try fm.moveItem(at: staging, to: destination)
    }

    private func waitUntilImportFinishes(
        store: PatchProjectStore,
        timeout: TimeInterval
    ) async -> Bool {
        let deadline = Date().addingTimeInterval(timeout)

        while Date() < deadline {
            if !store.isBusy {
                return true
            }
            try? await Task.sleep(for: .milliseconds(100))
        }

        return !store.isBusy
    }
}

// MARK: - Download All Patches state

/// Tracks the per-file progress of a batch download session.
struct PatchDownloadProgress: Identifiable {
    let id: String            // mirrors OnlineFileItem.id
    let title: String
    var fraction: Double      // 0.0 … 1.0
    var status: DownloadStatus

    enum DownloadStatus {
        case pending, downloading, importing, done, failed(String)
    }
}

// MARK: - Download All Sheet

struct OnlineFilesSheetView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var fetcher = OnlineFileFetcher()
    @ObservedObject var store: PatchProjectStore

    // Single-file state (existing behaviour)
    @State private var downloadingFileID: String?
    @State private var showSuccessToast = false

    // Batch download state (Feature 1)
    @State private var batchProgresses: [PatchDownloadProgress] = []
    @State private var isBatchRunning = false
    @State private var batchDoneCount = 0
    @State private var batchErrorCount = 0
    @State private var showBatchSummary = false

    // Auto-start: chỉ kích hoạt 1 lần ngay sau khi fetch xong
    @State private var autoStarted = false

    private var allDone: Bool { batchProgresses.allSatisfy { if case .done = $0.status { return true }; return false } }
    private var isSingleBusy: Bool { downloadingFileID != nil }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                Color(red: 0.04, green: 0.05, blue: 0.07).ignoresSafeArea()
                GridBackgroundView(spacing: 25, lineColor: Color.cyan.opacity(0.05)).ignoresSafeArea()

                VStack(spacing: 0) {
                    if fetcher.isLoading {
                        Spacer()
                        VStack(spacing: 20) {
                            ProgressView()
                                .progressViewStyle(.circular)
                                .tint(.cyan)
                                .scaleEffect(1.5)
                            Text("Đang đồng bộ máy chủ...")
                                .font(.headline)
                                .foregroundColor(.cyan)
                        }
                        Spacer()
                    } else if fetcher.onlineFiles.isEmpty {
                        Spacer()
                        VStack(spacing: 12) {
                            Image(systemName: "cloud.slash")
                                .font(.system(size: 45))
                                .foregroundColor(.gray)
                            Text("Không có bản Patch nào trên Server")
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    } else {
                        // ── Download All button ──────────────────────────────
                        downloadAllButton
                            .padding(.horizontal, 16)
                            .padding(.top, 12)

                        // ── Batch progress list ──────────────────────────────
                        if isBatchRunning || !batchProgresses.isEmpty {
                            batchProgressSection
                                .padding(.horizontal, 16)
                                .padding(.top, 8)
                        }

                        // ── Individual file cards ───────────────────────────
                        ScrollView {
                            LazyVStack(spacing: 16) {
                                ForEach(fetcher.onlineFiles) { file in
                                    onlineItemCardView(file)
                                }
                            }
                            .padding(16)
                            .padding(.top, showSuccessToast ? 60 : 10)
                        }
                    }
                }

                if showSuccessToast {
                    successToastView
                        .transition(.asymmetric(
                            insertion: .move(edge: .top).combined(with: .opacity),
                            removal: .opacity
                        ))
                        .zIndex(1)
                }
            }
            .navigationTitle("Download File")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 24))
                            .foregroundColor(Color.gray.opacity(0.7))
                    }
                }
            }
            .task {
                await fetcher.fetchServerFiles()
                // REQ 1: Auto-start handled by AutoPatchEngine (banner in top-right).
                // OnlineFilesSheetView is now only opened manually; batch auto-run removed here.
            }
            .alert("Tải Về Hoàn Tất", isPresented: $showBatchSummary) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Đã tải \(batchDoneCount) patch thành công" +
                     (batchErrorCount > 0 ? ", \(batchErrorCount) thất bại." : "."))
            }
        }
    }

    // MARK: Download All Button

    private var downloadAllButton: some View {
        Button {
            guard !isBatchRunning, !isSingleBusy else { return }
            startBatchDownload()
        } label: {
            HStack(spacing: 10) {
                if isBatchRunning {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                        .scaleEffect(0.85)
                } else {
                    Image(systemName: "arrow.down.to.line.circle.fill")
                        .font(.system(size: 20, weight: .semibold))
                }
                Text(isBatchRunning ? "Đang Tải Xuống…" : "Download All Patches")
                    .font(.system(size: 15, weight: .bold))
            }
            .foregroundColor(isBatchRunning ? .white.opacity(0.7) : .white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .background(
                LinearGradient(
                    colors: isBatchRunning
                        ? [Color.gray.opacity(0.4), Color.gray.opacity(0.3)]
                        : [Color.cyan.opacity(0.75), Color(red: 0.08, green: 0.45, blue: 0.75)],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.clear, lineWidth: 0)
            )
        }
        .disabled(isBatchRunning || isSingleBusy || fetcher.onlineFiles.isEmpty)
        .animation(.easeInOut(duration: 0.2), value: isBatchRunning)
    }

    // MARK: Batch Progress Section

    @ViewBuilder
    private var batchProgressSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Tiến Trình Tải Xuống")
                .font(.caption.weight(.semibold))
                .foregroundColor(.gray)

            ForEach(batchProgresses) { progress in
                batchProgressRow(progress)
            }
        }
        .padding(12)
        .background(Color(red: 0.10, green: 0.12, blue: 0.18).opacity(0.85))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Color.clear, lineWidth: 0)
        )
    }

    @ViewBuilder
    private func batchProgressRow(_ p: PatchDownloadProgress) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(p.title)
                    .font(.caption.weight(.medium))
                    .foregroundColor(.white)
                    .lineLimit(1)
                Spacer()
                batchStatusLabel(p.status)
            }
            ProgressView(value: p.fraction)
                .progressViewStyle(.linear)
                .tint(batchTint(p.status))
                .animation(.easeInOut(duration: 0.15), value: p.fraction)
        }
    }

    private func batchStatusLabel(_ status: PatchDownloadProgress.DownloadStatus) -> some View {
        Group {
            switch status {
            case .pending:
                Text("Chờ").font(.caption2).foregroundColor(.gray)
            case .downloading:
                Text("Đang tải").font(.caption2).foregroundColor(.cyan)
            case .importing:
                Text("Đang nhập").font(.caption2).foregroundColor(.yellow)
            case .done:
                Image(systemName: "checkmark.circle.fill")
                    .font(.caption2)
                    .foregroundColor(.green)
            case .failed(let msg):
                Text(msg)
                    .font(.caption2)
                    .foregroundColor(.red)
                    .lineLimit(1)
            }
        }
    }

    private func batchTint(_ status: PatchDownloadProgress.DownloadStatus) -> Color {
        switch status {
        case .pending: return .gray
        case .downloading: return .cyan
        case .importing: return .yellow
        case .done: return .green
        case .failed: return .red
        }
    }

    // MARK: Batch Download Logic

    private func startBatchDownload() {
        let files = fetcher.onlineFiles
        guard !files.isEmpty else { return }
        isBatchRunning = true
        batchDoneCount = 0
        batchErrorCount = 0
        batchProgresses = files.map {
            PatchDownloadProgress(id: $0.id, title: $0.title, fraction: 0, status: .pending)
        }

        Task(priority: .userInitiated) {
            // PatchProjectStore is deliberately serialized: importPackage()
            // rejects a second import while the first transaction is busy.
            // Running these imports concurrently silently drops every import
            // after the first one. Downloads remain complete, but installation
            // is performed one package at a time and each import is awaited.
            for file in files {
                if Task.isCancelled { break }
                await downloadSingleForBatch(file)
            }
            await MainActor.run {
                isBatchRunning = false
                showBatchSummary = true
            }
        }
    }

    private func downloadSingleForBatch(_ file: OnlineFileItem) async {
        guard let rawURL = file.url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: rawURL) else {
            updateBatch(id: file.id, fraction: 0, status: .failed("URL không hợp lệ"))
            await MainActor.run { batchErrorCount += 1 }
            return
        }

        // Validate HTTPS
        guard url.scheme?.lowercased() == "https", url.host != nil else {
            updateBatch(id: file.id, fraction: 0, status: .failed("URL phải HTTPS"))
            await MainActor.run { batchErrorCount += 1 }
            return
        }

        updateBatch(id: file.id, fraction: 0.05, status: .downloading)

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 45
        config.timeoutIntervalForResource = 300
        config.waitsForConnectivity = true

        do {
            let (temporaryURL, response) = try await URLSession(configuration: config).download(from: url)
            defer { try? FileManager.default.removeItem(at: temporaryURL) }

            guard let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode) else {
                throw URLError(.badServerResponse)
            }

            updateBatch(id: file.id, fraction: 0.6, status: .importing)

            let fileName = file.filename.isEmpty ? url.lastPathComponent : file.filename
            let finalName = fileName.hasSuffix(".3105") ? fileName : "\(fileName).3105"
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent("\(UUID().uuidString)-\(finalName)")

            try FileManager.default.copyItem(at: temporaryURL, to: dest)
            defer { try? FileManager.default.removeItem(at: dest) }

            let imported = await store.importPackageAndWait(at: dest)
            guard imported else {
                updateBatch(id: file.id, fraction: 0, status: .failed("Import thất bại"))
                await MainActor.run { batchErrorCount += 1 }
                return
            }

            log("batch-download: imported \(finalName)")
            updateBatch(id: file.id, fraction: 1.0, status: .done)
            await MainActor.run { batchDoneCount += 1 }

        } catch {
            let msg = (error as? URLError)?.localizedDescription ?? "Lỗi tải xuống"
            log("batch-download: failed \(file.filename) – \(error.localizedDescription)")
            updateBatch(id: file.id, fraction: 0, status: .failed(msg))
            await MainActor.run { batchErrorCount += 1 }
        }
    }

    @MainActor
    private func updateBatch(id: String, fraction: Double, status: PatchDownloadProgress.DownloadStatus) {
        guard let idx = batchProgresses.firstIndex(where: { $0.id == id }) else { return }
        batchProgresses[idx].fraction = fraction
        batchProgresses[idx].status = status
    }

    // MARK: Individual card (unchanged appearance, single download)

    private var successToastView: some View {
        HStack(spacing: 12) {
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 26))
                .foregroundColor(.green)
                .background(Circle().fill(Color.white).frame(width: 14, height: 14))
            Text("Đã Tải File Xuống Và Patch Thành Công")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 9)
        .background(Color(red: 0.08, green: 0.15, blue: 0.1).opacity(0.95))
        .cornerRadius(30)
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.clear, lineWidth: 0))
        .shadow(color: Color.green.opacity(0.4), radius: 15, x: 0, y: 5)
        .padding(.top, 16)
    }

    @ViewBuilder
    private func onlineItemCardView(_ file: OnlineFileItem) -> some View {
        HStack(spacing: 14) {
            Image(systemName: "cloud.fill")
                .font(.system(size: 24))
                .foregroundColor(.cyan)
                .frame(width: 44, height: 44)
                .background(Color.cyan.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 12))

            VStack(alignment: .leading, spacing: 4) {
                Text(file.title)
                    .font(.body.weight(.semibold))
                    .foregroundColor(.white)
                Text(file.filename)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            Button {
                downloadAndImport(file: file)
            } label: {
                if downloadingFileID == file.id {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.cyan)
                        .padding(8)
                } else {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.cyan)
                        .background(Circle().fill(Color.black))
                }
            }
            .disabled(downloadingFileID != nil || isBatchRunning)
        }
        .padding(16)
        .background(Color(red: 0.10, green: 0.14, blue: 0.20).opacity(0.8))
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.clear, lineWidth: 0)
        )
    }

    // Existing single-file download (unchanged logic, migrated to async/await)
    private func downloadAndImport(file: OnlineFileItem) {
        guard let rawURL = file.url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: rawURL) else { return }
        downloadingFileID = file.id

        Task(priority: .userInitiated) {
            defer { downloadingFileID = nil }
            do {
                let config = URLSessionConfiguration.default
                config.timeoutIntervalForRequest = 45
                config.timeoutIntervalForResource = 120
                config.waitsForConnectivity = true
                let (temporaryURL, _) = try await URLSession(configuration: config).download(from: url)
                defer { try? FileManager.default.removeItem(at: temporaryURL) }

                let fileName = file.filename.isEmpty ? url.lastPathComponent : file.filename
                let finalName = fileName.hasSuffix(".3105") ? fileName : "\(fileName).3105"
                let dest = FileManager.default.temporaryDirectory
                    .appendingPathComponent("\(UUID().uuidString)-\(finalName)")

                try FileManager.default.copyItem(at: temporaryURL, to: dest)
                defer { try? FileManager.default.removeItem(at: dest) }

                store.importPackage(at: dest)
                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) { showSuccessToast = true }
                try? await Task.sleep(nanoseconds: 2_500_000_000)
                withAnimation(.easeOut(duration: 0.5)) { showSuccessToast = false }
            } catch {
                log("single-download: failed \(file.filename) – \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Main Patch Projects View

struct PatchProjectsView: View {
    @StateObject private var store = PatchProjectStore()
    @ObservedObject private var appearance = AppearanceSettings.shared
    @StateObject private var patchState = PatchToggleStore()
    @ObservedObject private var autoPatch = AutoPatchEngine.shared

    /// Mỗi configuration không xác định được đều giữ một group riêng.
    /// Không có group tổng hợp "Khác", vì việc gom các package khác nhau vào
    /// cùng một bucket làm mất khả năng hiển thị configuration độc lập.
    private var groups: [PatchAppGroup] {
        PatchAppGrouping.makeGroups(from: store.items)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                GlobalBackground()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 18) {
                        LazyVGrid(
                            columns: [
                                GridItem(.flexible(minimum: 0), spacing: 8),
                                GridItem(.flexible(minimum: 0), spacing: 8)
                            ],
                            alignment: .center,
                            spacing: 8
                        ) {
                            ForEach(groups) { group in
                                NavigationLink {
                                    PatchAppDetailView(
                                        group: group,
                                        appearance: appearance,
                                        patchState: patchState
                                    )
                                } label: {
                                    PatchAppCard(group: group, appearance: appearance)
                                }
                                .buttonStyle(.plain).techButtonChrome()
                            }
                        }

                        if groups.isEmpty {
                            emptyState
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.top, 10)
                    .padding(.bottom, 96)
                }

            }
            .navigationTitle("Chức năng")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                // Load the local library first so existing patches are visible
                // immediately, then start AUTO against this same store.
                store.reload()
                AutoPatchEngine.shared.configure(store: store)
                AutoPatchEngine.shared.trigger()
            }
            .onChange(of: autoPatch.hasCompleted) { completed in
                guard completed else { return }
                // AUTO has finished importing; perform one final UI refresh
                // before the embedded spinner is removed.
                store.reload()
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "square.grid.2x2")
                .font(.system(size: 42, weight: .light))
                .foregroundStyle(appearance.resolvedAppButtonColor)
            Text("Chưa có chức năng")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("Các nhóm FFM, FFTH, CAPCUT, PUBG và LIÊN QUÂN đã được chuẩn bị sẵn.")
                .font(.system(size: 13))
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 80)
    }
}

// MARK: - Patch toggle state

@MainActor
final class PatchToggleStore: ObservableObject {
    @Published private(set) var enabledIDs: Set<UUID>
    @Published private(set) var busyIDs: Set<UUID> = []
    @Published private(set) var remainingSeconds: [UUID: Int] = [:]
    @Published var errorMessage: String?

    private let storageKey = "PatchProjects.enabledPatchIDs.v2"
    private let deadlinesStorageKey = "PatchProjects.autoDisableDeadlines.v1"
    private var autoDisableTasks: [UUID: Task<Void, Never>] = [:]
    private var autoDisableDeadlines: [UUID: Date] = [:]
    private var autoDisableSettingsObserver: NSObjectProtocol?

    init() {
        let values = UserDefaults.standard.stringArray(forKey: storageKey) ?? []
        enabledIDs = Set(values.compactMap(UUID.init(uuidString:)))
        autoDisableDeadlines = Self.loadDeadlines()

        autoDisableSettingsObserver = NotificationCenter.default.addObserver(
            forName: .fluxCoreAutoDisableSettingsChanged,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                // A settings change starts a fresh configured interval for
                // already-enabled patches instead of retaining the old deadline.
                self.autoDisableDeadlines.removeAll()
                self.persistDeadlines()
                self.refreshAutoDisableSchedules()
            }
        }
    }

    func isEnabled(_ item: PatchLibraryItem) -> Bool {
        enabledIDs.contains(item.id)
    }

    func isBusy(_ item: PatchLibraryItem) -> Bool {
        busyIDs.contains(item.id)
    }

    /// The transaction journal is the source of truth for the actual filesystem
    /// state. UserDefaults is only a persistence hint for the UI.
    func reconcile(_ items: [PatchLibraryItem]) {
        currentItems = items
        var actualEnabled = enabledIDs
        let ids = Set(items.map(\.id))
        actualEnabled.subtract(ids)

        for item in items {
            if DevicePatchService.latestAppliedReceipt(projectID: item.id) != nil {
                actualEnabled.insert(item.id)
            } else {
                actualEnabled.remove(item.id)
            }
        }

        if actualEnabled != enabledIDs {
            enabledIDs = actualEnabled
            persist()
        }
        refreshAutoDisableSchedules()
    }

    /// Changes the real patch state, not merely the visual toggle. ON creates a
    /// transaction and writes the replacement files. OFF restores the verified
    /// originals from that transaction. The UI state is committed only after the
    /// filesystem operation succeeds.
    func setEnabled(_ enabled: Bool, for item: PatchLibraryItem) {
        guard !busyIDs.contains(item.id) else { return }

        // Manual OFF always cancels a pending automatic restore for this patch.
        if !enabled {
            autoDisableTasks[item.id]?.cancel()
            autoDisableTasks[item.id] = nil
            autoDisableDeadlines[item.id] = nil
            remainingSeconds[item.id] = nil
            persistDeadlines()
        }
        guard let baseProject = item.project else {
            errorMessage = "Patch này đang bị khóa. Hãy mở khóa package trước khi bật."
            return
        }

        let projectID = item.id
        let itemSnapshot = item
        let baseProjectSnapshot = baseProject

        busyIDs.insert(projectID)
        errorMessage = nil

        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                if enabled {
                    let project: PatchProject
                    if itemSnapshot.summary.schemaVersion >= 2 {
                        project = try PatchProjectLibrary.synchronizeWorkspace(item: itemSnapshot)
                    } else {
                        project = baseProjectSnapshot
                    }

                    // Smart replacement: terminate only active patches that
                    // conflict with the incoming target set, then apply the new
                    // transaction. Unrelated active patches remain untouched.
                    let deactivatedIDs = try DevicePatchService.deactivateConflictingPatches(
                        project: project,
                        excludingProjectID: projectID
                    )
                    if !deactivatedIDs.isEmpty {
                        await self?.markAutoDeactivated(deactivatedIDs)
                    }

                    // Replace an older transaction belonging to this same project
                    // with a fresh backup of the current originals.
                    if let previousReceipt = DevicePatchService.latestReceipt(projectID: projectID) {
                        try DevicePatchService.restore(receipt: previousReceipt)
                    }

                    _ = try DevicePatchService.apply(project: project)
                } else {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        await self?.finishToggle(projectID: projectID, enabled: false)
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                }

                await self?.finishToggle(projectID: projectID, enabled: enabled)
            } catch let error as PatchPackageError {
                await self?.failToggle(
                    projectID: projectID,
                    message: error.errorDescription ?? "Không thể thay đổi trạng thái patch."
                )
            } catch {
                await self?.failToggle(
                    projectID: projectID,
                    message: error.localizedDescription
                )
            }
        }
    }

    private func markAutoDeactivated(_ projectIDs: Set<UUID>) {
        for id in projectIDs {
            enabledIDs.remove(id)
            autoDisableTasks[id]?.cancel()
            autoDisableTasks[id] = nil
            autoDisableDeadlines[id] = nil
            remainingSeconds[id] = nil
        }
        persistDeadlines()
        persist()

        if !projectIDs.isEmpty {
            FluxStatusNotificationCenter.shared.post(
                title: "Patch replaced",
                detail: "Conflicting patch automatically deactivated",
                isOn: false
            )
        }
    }

    func toggle(_ item: PatchLibraryItem) {
        setEnabled(!isEnabled(item), for: item)
    }

    func clearError() {
        errorMessage = nil
    }

    private func finishToggle(projectID: UUID, enabled: Bool) {
        if enabled {
            enabledIDs.insert(projectID)
            autoDisableDeadlines[projectID] = nil
        } else {
            enabledIDs.remove(projectID)
            autoDisableTasks[projectID]?.cancel()
            autoDisableTasks[projectID] = nil
            autoDisableDeadlines[projectID] = nil
            remainingSeconds[projectID] = nil
            persistDeadlines()
        }
        persist()
        busyIDs.remove(projectID)

        if enabled {
            scheduleAutoDisableIfNeeded(for: projectID)
        }

        FluxStatusNotificationCenter.shared.post(
            title: "Patch \(enabled ? "enabled" : "disabled")",
            detail: "Patch state updated successfully",
            isOn: enabled
        )
    }

    /// Schedules exactly one restore operation per enabled patch and maintains a
    /// live UI countdown. The persisted deadline survives relaunches.
    private func scheduleAutoDisableIfNeeded(for projectID: UUID) {
        autoDisableTasks[projectID]?.cancel()
        autoDisableTasks[projectID] = nil
        remainingSeconds[projectID] = nil

        let settings = AppearanceSettings.shared
        guard settings.autoDisablePatches else {
            autoDisableDeadlines[projectID] = nil
            persistDeadlines()
            return
        }

        let now = Date()
        let deadline = autoDisableDeadlines[projectID] ?? now.addingTimeInterval(
            min(max(settings.autoDisablePatchSeconds, 1), 20)
        )
        autoDisableDeadlines[projectID] = deadline
        persistDeadlines()

        autoDisableTasks[projectID] = Task { @MainActor [weak self] in
            guard let self else { return }

            while !Task.isCancelled {
                let remaining = Int(ceil(deadline.timeIntervalSinceNow))
                if remaining <= 0 {
                    self.remainingSeconds[projectID] = 0
                    self.autoDisableTasks[projectID] = nil
                    self.autoDisableDeadlines[projectID] = nil
                    self.persistDeadlines()

                    guard settings.autoDisablePatches,
                          let item = self.itemForAutoDisable(projectID),
                          self.isEnabled(item),
                          !self.isBusy(item) else {
                        self.remainingSeconds[projectID] = nil
                        return
                    }

                    self.setEnabled(false, for: item)
                    return
                }

                self.remainingSeconds[projectID] = remaining
                do {
                    try await Task.sleep(nanoseconds: 100_000_000)
                } catch {
                    return
                }
            }
        }
    }

    private func itemForAutoDisable(_ projectID: UUID) -> PatchLibraryItem? {
        // The patch list is not retained by the store, so the current UI supplies
        // the concrete item through the helper below when scheduling is refreshed.
        currentItems.first { $0.id == projectID }
    }

    private var currentItems: [PatchLibraryItem] = []

    func updateAutoDisableItems(_ items: [PatchLibraryItem]) {
        currentItems = items
        refreshAutoDisableSchedules()
    }

    private func refreshAutoDisableSchedules() {
        autoDisableTasks.values.forEach { $0.cancel() }
        autoDisableTasks.removeAll()

        guard AppearanceSettings.shared.autoDisablePatches else {
            remainingSeconds.removeAll()
            autoDisableDeadlines.removeAll()
            persistDeadlines()
            return
        }

        for projectID in enabledIDs {
            scheduleAutoDisableIfNeeded(for: projectID)
        }
    }

    private func failToggle(projectID: UUID, message: String) {
        busyIDs.remove(projectID)
        errorMessage = message
    }

    deinit {
        autoDisableTasks.values.forEach { $0.cancel() }
        if let observer = autoDisableSettingsObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    private func persistDeadlines() {
        let encoded = autoDisableDeadlines.reduce(into: [String: Double]()) { result, pair in
            result[pair.key.uuidString] = pair.value.timeIntervalSince1970
        }
        UserDefaults.standard.set(encoded, forKey: deadlinesStorageKey)
    }

    private static func loadDeadlines() -> [UUID: Date] {
        guard let raw = UserDefaults.standard.dictionary(forKey: "PatchProjects.autoDisableDeadlines.v1") as? [String: Double] else {
            return [:]
        }
        return raw.reduce(into: [UUID: Date]()) { result, pair in
            if let id = UUID(uuidString: pair.key) {
                result[id] = Date(timeIntervalSince1970: pair.value)
            }
        }
    }

    private func persist() {
        UserDefaults.standard.set(
            enabledIDs.map(\.uuidString).sorted(),
            forKey: storageKey
        )
    }
}

// MARK: - Patch function info

private enum PatchInfoTopic: Identifiable {
    case function(PatchType)
    case patch(PatchType)

    var id: String {
        switch self {
        case .function(let type): return "function-\(type.rawValue)"
        case .patch(let type): return "patch-\(type.rawValue)"
        }
    }

    var type: PatchType {
        switch self {
        case .function(let type), .patch(let type): return type
        }
    }

    var titleKey: String {
        switch self {
        case .function: return "patch.info.function.title"
        case .patch: return "patch.info.patch.title"
        }
    }

    var descriptionKey: String {
        switch self {
        case .function(let type):
            switch type {
            case .aim: return "patch.info.aim.description"
            case .holo: return "patch.info.holo.description"
            case .mod: return "patch.info.mod.description"
            }
        case .patch(let type):
            switch type {
            case .aim: return "patch.info.aim.toggle"
            case .holo: return "patch.info.holo.toggle"
            case .mod: return "patch.info.mod.toggle"
            }
        }
    }
}

private struct PatchFunctionInfoSheet: View {
    let topic: PatchInfoTopic
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @ObservedObject private var appearance = AppearanceSettings.shared

    var body: some View {
        ZStack {
            Color.black.opacity(0.94).ignoresSafeArea()

            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 12) {
                    Image(systemName: "info.circle.fill")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(appearance.resolvedAppButtonColor)
                    Text(language.text(topic.titleKey, topic.type.rawValue.uppercased()))
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Spacer()
                    Button(language.text("common.close")) { dismiss() }
                        .buttonStyle(.bordered)
                        .tint(appearance.resolvedAppButtonColor)
                }

                Text(language.text(topic.descriptionKey))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(.white.opacity(0.72))
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 10) {
                    Image(systemName: "hand.tap.fill")
                        .foregroundStyle(appearance.resolvedAppButtonColor)
                    Text(language.text("patch.info.badge_note"))
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.55))
                }
                .padding(12)
                .background(
                    Color.white.opacity(0.05),
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                )
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.clear, lineWidth: 0)
                }

                Spacer()
            }
            .padding(20)
        }
    }
}

// MARK: - App grouping

struct PatchAppGroup: Identifiable, Hashable {
    let id: String
    let name: String
    let bundleIdentifiers: [String]
    let items: [PatchLibraryItem]
    let kind: PatchAppKind

    var packageNames: [String] {
        items.map { $0.packageURL.lastPathComponent }
    }

    /// AIM/HOLO/MOD are a dedicated UI concept for FFM/FFTH only.
    /// Other applications expose their patches directly and therefore do not
    /// carry these three function buckets in the UI.
    var aimItems: [PatchLibraryItem] {
        guard kind == .ffm || kind == .ffth else { return [] }
        return items.filter {
            PatchType.classify(PatchAppGrouping.classificationName(for: $0)) == .aim
        }
    }

    var holoItems: [PatchLibraryItem] {
        guard kind == .ffm || kind == .ffth else { return [] }
        return items.filter {
            PatchType.classify(PatchAppGrouping.classificationName(for: $0)) == .holo
        }
    }

    var modItems: [PatchLibraryItem] {
        guard kind == .ffm || kind == .ffth else { return [] }
        return items.filter {
            PatchType.classify(PatchAppGrouping.classificationName(for: $0)) == .mod
        }
    }

    var primaryBundleID: String? { bundleIdentifiers.first }

    static func == (lhs: PatchAppGroup, rhs: PatchAppGroup) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

enum PatchAppKind: String, CaseIterable {
    case ffm
    case ffth
    case capcut
    case pubg
    case lienQuan
    case locket
    case other

    var displayName: String {
        switch self {
        case .ffm: return "FFM"
        case .ffth: return "FFTH"
        case .capcut: return "CAPCUT"
        case .pubg: return "PUBG"
        case .lienQuan: return "LIÊN QUÂN"
        case .locket: return "LOCKET"
        case .other: return "Khác"
        }
    }

    var defaultBundleID: String? {
        switch self {
        case .ffm: return "com.dts.freefiremax"
        case .ffth: return "com.dts.freefireth"
        case .capcut: return "com.lemon.lvoverseas"
        case .pubg: return "com.tencent.ig"
        case .lienQuan: return "com.garena.game.kgvn"
        case .locket: return "com.locket.Locket"
        case .other: return nil
        }
    }
}

enum PatchAppGrouping {
    private static let predefined: [(kind: PatchAppKind, name: String)] = [
        (.ffm, "FFM"),
        (.ffth, "FFTH"),
        (.capcut, "CAPCUT"),
        (.pubg, "PUBG"),
        (.lienQuan, "LIÊN QUÂN"),
        (.locket, "LOCKET")
    ]

    static func makeGroups(from items: [PatchLibraryItem]) -> [PatchAppGroup] {
        var buckets: [String: [PatchLibraryItem]] = [:]
        var kinds: [String: PatchAppKind] = [:]
        var names: [String: String] = [:]
        var bundles: [String: [String]] = [:]

        // Always create the requested top-level buttons, even before a patch exists.
        for (kind, name) in predefined {
            let key = key(for: kind)
            buckets[key] = []
            kinds[key] = kind
            names[key] = name
            if let bundleID = kind.defaultBundleID {
                bundles[key] = [bundleID]
            }
        }

        for item in items {
            let raw = classificationName(for: item)
            let kind = classifyKind(raw)
            let groupKey: String

            switch kind {
            case .ffm: groupKey = key(for: .ffm)
            case .ffth: groupKey = key(for: .ffth)
            case .capcut: groupKey = key(for: .capcut)
            case .pubg: groupKey = key(for: .pubg)
            case .lienQuan: groupKey = key(for: .lienQuan)
            case .locket: groupKey = key(for: .locket)
            case .other:
                groupKey = canonicalOtherKey(raw)
            }

            buckets[groupKey, default: []].append(item)
            kinds[groupKey] = kind

            if names[groupKey] == nil {
                names[groupKey] = displayName(for: raw, item: item)
            }

            for bundleID in item.project?.allBundleIdentifiers ?? [] where !bundleID.isEmpty {
                if !(bundles[groupKey] ?? []).contains(bundleID) {
                    bundles[groupKey, default: []].append(bundleID)
                }
            }
        }

        return buckets.compactMap { key, groupedItems in
            guard let kind = kinds[key], let name = names[key] else { return nil }
            let sortedItems = groupedItems.sorted {
                $0.packageURL.lastPathComponent.localizedCaseInsensitiveCompare(
                    $1.packageURL.lastPathComponent
                ) == .orderedAscending
            }

            return PatchAppGroup(
                id: key,
                name: name,
                bundleIdentifiers: bundles[key] ?? [],
                items: sortedItems,
                kind: kind
            )
        }
        .sorted { lhs, rhs in
            let order: [PatchAppKind] = [.ffm, .ffth, .capcut, .pubg, .lienQuan, .locket, .other]
            let li = order.firstIndex(of: lhs.kind) ?? order.count
            let ri = order.firstIndex(of: rhs.kind) ?? order.count
            if li != ri { return li < ri }
            return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
        }
    }

    static func classificationName(for item: PatchLibraryItem) -> String {
        let project = item.project?.name ?? ""
        let filename = item.packageURL.deletingPathExtension().lastPathComponent
        return project.isEmpty ? filename : "\(project) \(filename)"
    }

    private static func classifyKind(_ raw: String) -> PatchAppKind {
        let compact = normalizedCompact(raw)

        // FFTH and FFM are intentionally checked separately and never merged.
        if containsToken(compact, token: "ffth") { return .ffth }
        if containsToken(compact, token: "ffm") { return .ffm }
        if compact.contains("capcut") { return .capcut }
        if compact.contains("pubg") { return .pubg }
        if compact.contains("lienquan") { return .lienQuan }
        if compact.contains("locket") { return .locket }
        return .other
    }

    private static func canonicalOtherKey(_ value: String) -> String {
        let normalized = value
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .filter {
                !["aim", "holo", "mod", "patch", "3105"].contains($0.lowercased())
            }

        let result = normalized.joined(separator: " ").lowercased()
        return result.isEmpty ? "other" : "other-\(result)"
    }

    private static func key(for kind: PatchAppKind) -> String {
        "system-\(kind.rawValue)"
    }

    private static func normalizedCompact(_ value: String) -> String {
        value
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: "")
            .lowercased()
    }

    private static func containsToken(_ compact: String, token: String) -> Bool {
        compact.contains(token)
    }

    private static func displayName(for raw: String, item: PatchLibraryItem) -> String {
        switch classifyKind(raw) {
        case .ffm: return "FFM"
        case .ffth: return "FFTH"
        case .capcut: return "CAPCUT"
        case .pubg: return "PUBG"
        case .lienQuan: return "LIÊN QUÂN"
        case .locket: return "LOCKET"
        case .other:
            if let name = item.project?.name,
               !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return name
            }
            return item.packageURL.deletingPathExtension().lastPathComponent
        }
    }
}

// MARK: - App card

private struct PatchAppCard: View {
    private static let locketCoverPageURL = "https://ibb.co/8Lq2Dmd8"
    private static let locketCoverImageURL = "https://i.ibb.co/pBcZv1RX/IMG-8870.jpg"

    let group: PatchAppGroup
    @ObservedObject var appearance: AppearanceSettings
    @ObservedObject private var autoPatch = AutoPatchEngine.shared

    private var patchCount: Int { group.items.count }

    @ViewBuilder
    private var appCardIcon: some View {
        if group.kind == .locket {
            if let localURL = DynamicAssetRouter.assetURL(for: "system-locket") {
                AsyncImage(url: localURL) { phase in
                    if let image = phase.image {
                        image.resizable().scaledToFill()
                    } else {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
            } else if let url = URL(string: Self.locketCoverImageURL) {
                AsyncImage(url: url) { phase in
                    if let image = phase.image {
                        image.resizable().scaledToFill()
                    } else {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
            } else {
                Image(systemName: "heart.fill")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundStyle(.white)
            }
        } else {
            InstalledAppIconView(bundleID: group.primaryBundleID)
        }
    }

    var body: some View {
        VStack(spacing: 10) {
            appCardIcon
                .frame(width: 52, height: 52)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.clear, lineWidth: 0)
                }
                .shadow(color: appearance.resolvedAppButtonColor.opacity(0.16), radius: 12, y: 5)
                .appLaunchIconGlow()

            Text(group.name)
                .font(.system(size: 12.5, weight: appearance.fontWeight.swiftUI, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)

            Text(group.primaryBundleID ?? "Chưa có package")
                .font(.system(size: 8, weight: .medium, design: .monospaced))
                .foregroundStyle(.white.opacity(0.48))
                .lineLimit(1)
                .minimumScaleFactor(0.65)

            if group.kind == .ffm || group.kind == .ffth {
                HStack(spacing: 6) {
                    typeBadge("AIM", count: group.aimItems.count)
                    typeBadge("HOLO", count: group.holoItems.count)
                    typeBadge("MOD", count: group.modItems.count)
                }
            } else if group.kind == .other {
                // REQ 4: "Khác" badge — tech icon + patch toggle indicator
                HStack(spacing: 5) {
                    Image(systemName: "puzzlepiece.extension.fill")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundStyle(Color(red: 1.0, green: 0.72, blue: 0.10).opacity(0.88))
                    Text("PATCH MIX")
                        .font(.system(size: 6.5, weight: .black, design: .monospaced))
                        .tracking(0.8)
                        .foregroundStyle(Color(red: 1.0, green: 0.72, blue: 0.10).opacity(0.88))
                }
                .padding(.horizontal, 7)
                .padding(.vertical, 4)
                .background(
                    Color(red: 1.0, green: 0.72, blue: 0.10).opacity(0.12),
                    in: Capsule()
                )
                .overlay(Capsule().stroke(Color.clear, lineWidth: 0))
            }

            Group {
                if autoPatch.isRunning {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(appearance.resolvedAppButtonColor)
                        .scaleEffect(0.72)
                        .frame(height: 12)
                        .accessibilityLabel("Đang tự động tải Patch")
                } else if patchCount == 0 {
                    Text("Sẵn sàng tích hợp")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(appearance.resolvedAppButtonColor.opacity(0.82))
                } else {
                    Text("\(patchCount) patch")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(appearance.resolvedAppButtonColor.opacity(0.82))
                }
            }
        }
        .frame(maxWidth: .infinity)
        .frame(minHeight: 154)
        .padding(.horizontal, 10)
        .padding(.vertical, 9)
        .background(cardBackground)
        .overlay(cardBorder)
        .clipShape(RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(appearance.cardCornerRadius), style: .continuous))
        .shadow(color: appearance.resolvedAppButtonColor.opacity(0.08), radius: 12, y: 5)
        .opacity(appearance.globalOpacity)
    }

    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(appearance.cardCornerRadius), style: .continuous)
            .fill(
                LinearGradient(
                    colors: [
                        appearance.resolvedAppButtonColor.opacity(0.08),
                        Color.black.opacity(appearance.cardFillOpacity)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var cardBorder: some View {
        RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(appearance.cardCornerRadius), style: .continuous)
            .stroke(Color.clear, lineWidth: 0)
    }

    private func typeBadge(_ title: String, count: Int) -> some View {
        Text(count > 0 ? "\(title) \(count)" : title)
            .font(.system(size: 6.5, weight: .bold, design: .monospaced))
            .foregroundStyle(count > 0 ? appearance.resolvedAppButtonColor : .white.opacity(0.35))
            .padding(.horizontal, 5)
            .padding(.vertical, 4)
            .background(
                appearance.resolvedAppButtonColor.opacity(count > 0 ? 0.11 : 0.035),
                in: Capsule()
            )
        .accessibilityIdentifier(group.id == "system-locket" ? "patch.app.locket" : group.id)
    }
}

private struct InstalledAppIconView: View {
    let bundleID: String?
    @ObservedObject private var appearance = AppearanceSettings.shared

    private var suppliedIconURL: URL? {
        guard let bundleID else { return nil }

        switch bundleID {
        case "com.dts.freefireth":
            return URL(string: "https://i.ibb.co/27CQSgHV/IMG-8638.png")
        case "com.dts.freefiremax":
            return URL(string: "https://i.ibb.co/jZMDVKPs/IMG-8637.png")
        case "com.lemon.lvoverseas":
            return URL(string: "https://i.ibb.co/Gv6DThXB/IMG-8639.jpg")
        case "com.tencent.ig":
            return URL(string: "https://i.ibb.co/5Xvm4Nc6/IMG-8640.jpg")
        case "com.garena.game.kgvn":
            return URL(string: "https://i.ibb.co/3mr8wR8m/IMG-8641.jpg")
        default:
            return nil
        }
    }

    @ViewBuilder
    private var fallbackIcon: some View {
        if let bundleID, let image = iconForBundleID(bundleID) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
        } else {
            ZStack {
                LinearGradient(
                    colors: [
                        appearance.resolvedAppButtonColor.opacity(0.28),
                        Color.black.opacity(0.50)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                Image(systemName: "app.fill")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.88))
            }
        }
    }

    private var cachedIconURL: URL? {
        guard let bundleID else { return nil }
        switch bundleID {
        case "com.dts.freefireth": return AssetPreloadService.cachedURL(key: "icon.ffth")
        case "com.dts.freefiremax": return AssetPreloadService.cachedURL(key: "icon.ffm")
        case "com.lemon.lvoverseas": return AssetPreloadService.cachedURL(key: "icon.capcut")
        case "com.tencent.ig": return AssetPreloadService.cachedURL(key: "icon.pubg")
        case "com.garena.game.kgvn": return AssetPreloadService.cachedURL(key: "icon.lienquan")
        default: return nil
        }
    }

    var body: some View {
        Group {
            if let cachedIconURL {
                Image(uiImage: UIImage(contentsOfFile: cachedIconURL.path) ?? UIImage())
                    .resizable()
                    .scaledToFill()
            } else if let suppliedIconURL {
                AsyncImage(url: suppliedIconURL, transaction: Transaction(animation: .easeOut(duration: 0.20))) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    case .failure:
                        fallbackIcon
                    case .empty:
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(appearance.resolvedAppButtonColor.opacity(0.12))
                            ProgressView()
                                .tint(appearance.resolvedAppButtonColor)
                                .scaleEffect(0.75)
                        }
                    @unknown default:
                        fallbackIcon
                    }
                }
            } else {
                fallbackIcon
            }
        }
        .clipped()
        .accessibilityLabel(bundleID ?? "Application icon")
    }
}

// MARK: - App detail

private struct PatchAppDetailView: View {
    let group: PatchAppGroup
    @ObservedObject var appearance: AppearanceSettings
    @ObservedObject var patchState: PatchToggleStore
    @ObservedObject private var autoPatch = AutoPatchEngine.shared
    @Namespace private var selectorNamespace
    @ObservedObject private var functionSettings = PatchFunctionSettings.shared
    @Environment(\.appLanguage) private var language
    @State private var selectedType: PatchType = .aim
    @State private var openResult: String?
    @State private var infoTopic: PatchInfoTopic?

    /// FFM/FFTH expose the three function channels.
    /// Other applications intentionally expose their patches directly so they
    /// do not inherit the AIM/HOLO/MOD configuration UI.
    private var usesFunctionChannels: Bool {
        group.kind == .ffm || group.kind == .ffth
    }

    private var selectedItems: [PatchLibraryItem] {
        // REQ 4: .other always shows all its patches — they are fully toggleable.
        // FFM/FFTH use the AIM/HOLO/MOD channel filter.
        // All other known apps (CAPCUT, PUBG, LIÊN QUÂN) expose patches directly.
        guard usesFunctionChannels else { return group.items }
        switch selectedType {
        case .aim:  return group.aimItems
        case .holo: return group.holoItems
        case .mod:  return group.modItems
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            GlobalBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    detailHeader
                    if usesFunctionChannels {
                        typeSelector
                    }
                    requirementsSection
                }
                .padding(16)
                .padding(.bottom, 92)
            }

            openAppBar
                .padding(.trailing, 14)
                .padding(.bottom, 14)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                .zIndex(100)
        }
        .navigationTitle(group.name)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $infoTopic) { topic in
            PatchFunctionInfoSheet(topic: topic)
                .presentationDetents([.height(330), .medium])
                .presentationDragIndicator(.visible)
        }
        .alert("Không thể mở ứng dụng", isPresented: Binding(
            get: { openResult != nil },
            set: { if !$0 { openResult = nil } }
        )) {
            Button("OK", role: .cancel) { openResult = nil }
        } message: {
            Text(openResult ?? "Ứng dụng chưa được cài đặt hoặc không thể mở.")
        }
        .task {
            patchState.reconcile(group.items)
        }
        .alert("Không thể thay đổi patch", isPresented: Binding(
            get: { patchState.errorMessage != nil },
            set: { if !$0 { patchState.clearError() } }
        )) {
            Button("OK", role: .cancel) { patchState.clearError() }
        } message: {
            Text(patchState.errorMessage ?? "Không thể thay đổi trạng thái patch.")
        }
    }

    private var detailHeader: some View {
        // REQ 4: .other kind gets a dedicated "Khác" tech icon instead of an app icon
        let isOther = group.kind == .other
        let otherAccent = Color(red: 1.0, green: 0.72, blue: 0.10)  // amber gold for "Khác"
        let cr = appearance.appButtonStyle.cornerRadius(appearance.cardCornerRadius)

        return HStack(spacing: 14) {
            if isOther {
                // Tech icon for the "Khác" / unknown patch bucket
                ZStack {
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [otherAccent.opacity(0.30), otherAccent.opacity(0.08)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    Image(systemName: "puzzlepiece.extension.fill")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundStyle(otherAccent)
                        .shadow(color: otherAccent.opacity(0.60), radius: 10)
                }
                .frame(width: 74, height: 74)
                .overlay {
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(Color.clear, lineWidth: 0)
                }
                .shadow(color: otherAccent.opacity(0.30), radius: 12, y: 4)
            } else {
                InstalledAppIconView(bundleID: group.primaryBundleID)
                    .frame(width: 74, height: 74)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .stroke(Color.clear, lineWidth: 0)
                    }
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(group.name)
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)

                if isOther {
                    // REQ 4: Explain the "Khác" bucket
                    Text("Patch không xác định loại")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(otherAccent.opacity(0.72))
                        .lineLimit(1)
                } else if let bundle = group.primaryBundleID {
                    Text(bundle)
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.48))
                        .lineLimit(1)
                }

                Text(group.items.isEmpty ? "Chưa có patch" : "\(group.items.count) patch")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(isOther ? otherAccent : appearance.resolvedAppButtonColor)
            }
            Spacer()
        }
        .padding(14)
        .background(
            Color.white.opacity(0.045),
            in: RoundedRectangle(cornerRadius: cr, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: cr, style: .continuous)
                .stroke(Color.clear, lineWidth: 0)
        }
    }

    // MARK: - FLUXCORE: Redesigned AIM / HOLO / MOD selector (REQ 3)

    /// Full-width row of three futuristic function channel buttons.
    /// Each button carries a custom tech icon, a glow ring, and an animated
    /// selection state consistent with the Free Fire / FLUXCORE visual language.
    private var typeSelector: some View {
        HStack(spacing: 10) {
            ForEach(PatchType.allCases) { type in
                typeSelectorButton(for: type)
            }
        }
    }

    /// Returns the SF Symbol name that best represents each channel.
    /// AIM  → crosshair + gun (scope), HOLO → radar/location, MOD → wrench/mod
    private func typeIconName(_ type: PatchType) -> String {
        switch type {
        case .aim:  return "scope"                        // crosshair/scope — precision aim
        case .holo: return "dot.radiowaves.up.forward"    // radar/hologram signal
        case .mod:  return "wrench.adjustable.fill"       // mod tool
        }
    }

    /// Secondary decorative icon layered behind the primary icon.
    private func typeIconSecondary(_ type: PatchType) -> String {
        switch type {
        case .aim:  return "triangle.fill"
        case .holo: return "hexagon.fill"
        case .mod:  return "gear"
        }
    }

    /// One high-tech button cell for AIM, HOLO, or MOD.
    @ViewBuilder
    private func typeSelectorButton(for type: PatchType) -> some View {
        let isSelected = selectedType == type
        let accent = functionSettings.color(for: type)
        let visualOpacity = functionSettings.opacity(for: type) * appearance.functionSelectorOpacity
        let cornerRadius = CGFloat(min(max(appearance.functionSelectorCornerRadius, 8), 36))

        ZStack(alignment: .topTrailing) {
            Button {
                withAnimation(
                    appearance.animationsEnabled
                        ? .spring(response: 0.26 * appearance.animationDurationMultiplier, dampingFraction: 0.78)
                        : nil
                ) {
                    selectedType = type
                }
            } label: {
                ZStack {
                    if isSelected {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(accent.opacity(0.16))
                            .matchedGeometryEffect(id: "selected-channel", in: selectorNamespace)
                    }

                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(
                            isSelected
                                ? LinearGradient(
                                    colors: [
                                        accent.opacity(0.28),
                                        accent.opacity(0.10),
                                        Color.black.opacity(0.30)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                  )
                                : LinearGradient(
                                    colors: [Color.white.opacity(0.05), Color.white.opacity(0.02)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                  )
                        )

                    Image(systemName: typeIconSecondary(type))
                        .font(.system(size: 38, weight: .ultraLight))
                        .foregroundStyle(accent.opacity(isSelected ? 0.10 : 0.04))
                        .rotationEffect(.degrees(isSelected ? 30 : 0))
                        .scaleEffect(isSelected ? 1.12 : 1.0)
                        .animation(.easeInOut(duration: 0.5), value: isSelected)
                        .offset(x: 18, y: -10)

                    VStack(spacing: 6) {
                        ZStack {
                            Circle()
                                .fill(accent.opacity(isSelected ? 0.22 : 0.08))
                                .frame(width: 48, height: 48)
                                .blur(radius: 4)

                            Image(systemName: typeIconName(type))
                                .font(.system(size: 22, weight: .bold))
                                .foregroundStyle(accent)
                                .shadow(color: accent.opacity(0.75), radius: isSelected ? 8 : 3)
                        }

                        Text(type.rawValue.uppercased())
                            .font(.system(size: 11, weight: .black, design: .rounded))
                            .tracking(1.2)
                            .foregroundStyle(isSelected ? .white : Color.white.opacity(0.42))

                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)

                    if isSelected {
                        VStack {
                            Capsule()
                                .fill(accent)
                                .frame(width: 28, height: 2.5)
                                .shadow(color: accent.opacity(0.90), radius: 5)
                            Spacer()
                        }
                        .padding(.top, 0)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .contentShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            }
            .buttonStyle(.plain)
            .techBorder(
                enabled: appearance.technologyBorderEnabled,
                color: appearance.resolvedBorderColor,
                cornerRadius: cornerRadius,
                width: appearance.buttonBorderWidth
            )
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(Color.clear, lineWidth: 0)
            }
            .shadow(color: isSelected ? accent.opacity(0.35) : .clear, radius: 14, y: 4)
            .scaleEffect(isSelected ? 1.025 : 1.0)
            .opacity(visualOpacity)
            .animation(.spring(response: 0.28, dampingFraction: 0.80), value: isSelected)

            .padding(7)
            .accessibilityLabel("Thông tin \(type.rawValue)")
        }
    }

    private var requirementsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(usesFunctionChannels ? "Yêu cầu chức năng" : "Chức năng")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
            }

            if selectedItems.isEmpty {
                Text(
                    usesFunctionChannels
                        ? "Chưa có patch \(selectedType.rawValue) cho \(group.name)."
                        : "Chưa có patch cho \(group.name)."
                )
                    .font(.system(size: 13))
                    .foregroundStyle(.white.opacity(0.50))
                    .padding(.vertical, 20)
            } else {
                ForEach(selectedItems) { item in
                    patchRequirementRow(item)
                }
            }
        }
    }

    private func patchRequirementRow(_ item: PatchLibraryItem) -> some View {
        let busy = patchState.isBusy(item)
        let enabled = patchState.isEnabled(item)
        let itemType = PatchType.classify(PatchAppGrouping.classificationName(for: item))
        let visualOpacity = functionSettings.opacity(for: itemType)

        return HStack(spacing: 12) {
            Image(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(appearance.resolvedAppButtonColor)
                .frame(width: 38, height: 38)
                .background(
                    appearance.resolvedAppButtonColor.opacity(0.10),
                    in: RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(11), style: .continuous)
                )

            VStack(alignment: .leading, spacing: 4) {
                Text(item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                // Patch cards intentionally expose only the patch name and its
                // live enabled/disabled state; secondary metadata is hidden.
                Text(
                    busy ? "Đang xử lý…" :
                    enabled ? "Đang bật" : "Đang tắt"
                )
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(
                    busy ? appearance.resolvedAppButtonColor :
                    enabled ? appearance.resolvedAppButtonColor : .white.opacity(0.42)
                )
            }

            Spacer(minLength: 8)

            HStack(spacing: 7) {
                if appearance.autoDisablePatches && enabled,
                   let remaining = patchState.remainingSeconds[item.id] {
                    Text("\(remaining)s")
                        .font(.system(size: 12, weight: appearance.patchCountdownFontWeight.swiftUI, design: .monospaced))
                        .foregroundStyle((Color(hex: appearance.patchCountdownColorHex) ?? appearance.resolvedAppButtonColor)
                            .opacity(appearance.patchCountdownOpacity))
                        .padding(.horizontal, 7)
                        .padding(.vertical, 4)
                        .background(
                            (Color(hex: appearance.patchCountdownColorHex) ?? appearance.resolvedAppButtonColor)
                                .opacity(0.10 * appearance.patchCountdownOpacity),
                            in: Capsule()
                        )
                        .overlay {
                            Capsule()
                                .stroke(Color.clear, lineWidth: 0)
                        }
                        .accessibilityLabel("Tự động tắt sau \(remaining) giây")
                }


                ZStack {
                Toggle(
                    "",
                    isOn: Binding(
                        get: { enabled },
                        set: { patchState.setEnabled($0, for: item) }
                    )
                )
                .labelsHidden()
                .tint(appearance.resolvedAppButtonColor)
                .disabled(item.isLocked || busy)

                if busy {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(appearance.resolvedAppButtonColor)
                        .scaleEffect(0.72)
                }
                }
                .frame(width: 48, height: 32)
            }
        }
        .padding(12)
        .background {
            RoundedRectangle(
                cornerRadius: appearance.appButtonStyle.cornerRadius(16),
                style: .continuous
            )
            .fill(
                appearance.appButtonStyle == .futuristic
                    ? LinearGradient(
                        colors: [
                            appearance.resolvedAppButtonColor.opacity(0.16),
                            Color.black.opacity(max(0.12, appearance.cardFillOpacity * 0.72))
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    : LinearGradient(
                        colors: [
                            Color.black.opacity(max(0.10, appearance.cardFillOpacity * 0.70)),
                            Color.black.opacity(max(0.10, appearance.cardFillOpacity * 0.70))
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
            )
        }
        .overlay {
            RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(16), style: .continuous)
                .stroke(Color.clear, lineWidth: 0)
        }
        .shadow(
            color: appearance.appButtonStyle == .futuristic
                ? appearance.resolvedAppButtonColor.opacity(0.18 * visualOpacity)
                : .clear,
            radius: appearance.appButtonStyle == .futuristic ? 10 : 0,
            y: appearance.appButtonStyle == .futuristic ? 3 : 0
        )
        .opacity(0.35 + (0.65 * visualOpacity))
    }

    private var openAppBar: some View {
        Button {
            guard let bundleID = group.primaryBundleID,
                  !bundleID.isEmpty else {
                openResult = "Chức năng này chưa có package identifier của ứng dụng đích."
                return
            }

            guard openApplicationForBundleID(bundleID) else {
                openResult = "Ứng dụng chưa được cài đặt hoặc LaunchServices không thể mở package này."
                FluxStatusNotificationCenter.shared.post(
                    title: "App launch failed",
                    detail: group.name,
                    isOn: false
                )
                return
            }

            FluxStatusNotificationCenter.shared.post(
                title: "App launched",
                detail: group.name,
                isOn: true
            )
        } label: {
            ZStack {
                // The action label is independently centered. The trailing
                // progress indicator never changes the label's center point.
                HStack(spacing: 9) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 15, weight: .black))
                    Text("MỞ APP")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .tracking(1.0)
                }
                .frame(maxWidth: .infinity, alignment: .center)

                HStack {
                    Spacer()
                    if autoPatch.isRunning {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .tint(appearance.resolvedAppButtonColor)
                            .frame(width: 18, height: 18)
                            .accessibilityLabel("Đang tải Patch")
                    } else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 12, weight: .bold))
                            .opacity(0.65)
                    }
                }
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 18)
            .frame(maxWidth: .infinity)
            .frame(height: 58)
            .background(
                RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(18), style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(18), style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        appearance.resolvedAppButtonColor.opacity(0.035),
                                        Color.black.opacity(0.045)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
            )
            .overlay {
                if appearance.appButtonBorderEnabled {
                    RoundedRectangle(
                        cornerRadius: appearance.appButtonStyle.cornerRadius(18),
                        style: .continuous
                    )
                    .stroke(
                        appearance.resolvedAppButtonBorderColor.opacity(
                            appearance.appButtonBorderOpacity
                        ),
                        lineWidth: appearance.appButtonBorderWidth
                    )
                    .shadow(
                        color: appearance.appButtonGlowEnabled
                            ? (Color(hex: appearance.appButtonGlowColorHex) ?? appearance.resolvedAppButtonBorderColor)
                                .opacity(0.78 * appearance.appButtonGlowIntensity)
                            : .clear,
                        radius: appearance.appButtonGlowEnabled
                            ? CGFloat(appearance.appButtonGlowRadius)
                            : 0
                    )
                }
            }
            .shadow(
                color: appearance.appButtonGlowEnabled
                    ? (Color(hex: appearance.appButtonGlowColorHex) ?? appearance.resolvedAppButtonColor)
                        .opacity(0.58 * appearance.appButtonGlowIntensity)
                    : .clear,
                radius: appearance.appButtonGlowEnabled
                    ? CGFloat(appearance.appButtonGlowRadius)
                    : 0,
                y: 5
            )
            .shadow(color: .black.opacity(0.50), radius: 10, y: 5)
        }
        .buttonStyle(.plain)
        .contentShape(RoundedRectangle(cornerRadius: appearance.appButtonStyle.cornerRadius(18), style: .continuous))
        .accessibilityLabel("Mở ứng dụng")
        .animation(.easeInOut(duration: 0.18), value: autoPatch.isRunning)
    }

    private func count(for type: PatchType) -> Int {
        switch type {
        case .aim: return group.aimItems.count
        case .holo: return group.holoItems.count
        case .mod: return group.modItems.count
        }
    }
}

// MARK: - Grid background
// Uses the shared GridBackgroundView declared in ContentView.swift.

// MARK: - Unlock view (unchanged)

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote).foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

// MARK: - Patch Detail View (unchanged)

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?

    private var item: PatchLibraryItem? { store.items.first(where: { $0.id == projectID }) }
    private var receipt: PatchTransactionReceipt? { DevicePatchService.latestReceipt(projectID: projectID) }

    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.05, blue: 0.07).ignoresSafeArea()
            GridBackgroundView(spacing: 25, lineColor: Color.white.opacity(0.04)).ignoresSafeArea()

            List {
                if let item, let project = item.project {
                    Section {
                        HStack(spacing: 12) {
                            Image(systemName: "shippingbox.fill")
                                .font(.system(size: 20)).foregroundColor(.cyan)
                                .frame(width: 32, height: 32)
                                .background(Color.cyan.opacity(0.15))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(project.name)
                                    .font(.body.weight(.semibold)).foregroundColor(.white)
                                Text(item.summary.isPasswordProtected
                                     ? language.text("patch.password_locked")
                                     : language.text("patch.no_password"))
                                    .font(.caption).foregroundColor(.gray)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .listRowBackground(Color(red: 0.12, green: 0.12, blue: 0.18).opacity(0.4))

                    Section {
                        Button { showApplyConfirmation = true } label: {
                            HStack {
                                Label("Áp Dụng Patch", systemImage: "checkmark.shield.fill")
                                    .foregroundStyle(LinearGradient(
                                        colors: [Color(red: 0.3, green: 1.0, blue: 0.55), Color.green],
                                        startPoint: .leading, endPoint: .trailing
                                    ))
                                Spacer()
                                if isWorking {
                                    ProgressView()
                                        .progressViewStyle(.circular)
                                        .tint(.green)
                                        .scaleEffect(0.8)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .disabled(isWorking)

                        Button(role: .destructive) { showRestoreConfirmation = true } label: {
                            Label("Khôi Phục File Gốc", systemImage: "arrow.uturn.backward.circle")
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .disabled(isWorking || receipt == nil)
                    } header: {
                        Text("Hành Động")
                    }
                    .listRowBackground(Color(red: 0.12, green: 0.12, blue: 0.18).opacity(0.4))
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
        }
        .navigationTitle(item?.project?.name ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Xác nhận Kích Hoạt", isPresented: $showApplyConfirmation, titleVisibility: .visible) {
            Button("Kích Hoạt") { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog("Xác nhận Khôi Phục", isPresented: $showRestoreConfirmation, titleVisibility: .visible) {
            Button("Khôi Phục", role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(language.text(alert.message(language: language))),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}
